/** Estimates interest for savings accounts. Nothing is ever credited to the balance. */
public class InterestCalculator {

    public static final double ANNUAL_RATE = 0.04; // 4% per annum

    private InterestCalculator() { }

    /** Estimated interest for one year on the current balance; 0 for non-savings accounts. */
    public static double estimateAnnualInterest(Account account) {
        if (!account.isSavings()) return 0.0;
        return Account.round2(account.getBalance() * ANNUAL_RATE);
    }

    public static double estimateMonthlyInterest(Account account) {
        return Account.round2(estimateAnnualInterest(account) / 12.0);
    }
}
