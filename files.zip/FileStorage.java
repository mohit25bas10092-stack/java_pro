import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Saves and loads accounts and transactions as plain text files inside the data/ folder. */
public class FileStorage {

    private static final Path DATA_DIR = Paths.get("data");
    private static final Path ACCOUNTS_FILE = DATA_DIR.resolve("accounts.txt");
    private static final Path TRANSACTIONS_FILE = DATA_DIR.resolve("transactions.txt");

    private FileStorage() { }

    public static List<Account> loadAccounts() {
        List<Account> accounts = new ArrayList<>();
        for (String line : readLines(ACCOUNTS_FILE)) {
            try {
                accounts.add(Account.fromFileLine(line));
            } catch (RuntimeException e) {
                System.out.println("Warning: skipped unreadable account record.");
            }
        }
        return accounts;
    }

    public static List<Transaction> loadTransactions() {
        List<Transaction> transactions = new ArrayList<>();
        for (String line : readLines(TRANSACTIONS_FILE)) {
            try {
                transactions.add(Transaction.fromFileLine(line));
            } catch (RuntimeException e) {
                System.out.println("Warning: skipped unreadable transaction record.");
            }
        }
        return transactions;
    }

    public static void saveAccounts(List<Account> accounts) throws IOException {
        List<String> lines = new ArrayList<>();
        for (Account a : accounts) lines.add(a.toFileLine());
        writeLines(ACCOUNTS_FILE, lines);
    }

    public static void saveTransactions(List<Transaction> transactions) throws IOException {
        List<String> lines = new ArrayList<>();
        for (Transaction t : transactions) lines.add(t.toFileLine());
        writeLines(TRANSACTIONS_FILE, lines);
    }

    /** Writes a statement file and returns its path. */
    public static String saveStatement(String accountNumber, String text) {
        Path file = DATA_DIR.resolve("statement_" + accountNumber + ".txt");
        try {
            Files.createDirectories(DATA_DIR);
            Files.write(file, text.getBytes(StandardCharsets.UTF_8));
            return file.toString();
        } catch (IOException e) {
            throw new IllegalStateException("Could not save statement: " + e.getMessage());
        }
    }

    // ---- helpers ----

    private static List<String> readLines(Path file) {
        List<String> result = new ArrayList<>();
        if (!Files.exists(file)) return result;
        try {
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                if (!line.trim().isEmpty()) result.add(line);
            }
        } catch (IOException e) {
            System.out.println("Warning: could not read " + file + " (" + e.getMessage() + ")");
        }
        return result;
    }

    private static void writeLines(Path file, List<String> lines) throws IOException {
        Files.createDirectories(DATA_DIR);
        Files.write(file, lines, StandardCharsets.UTF_8);
    }
}
