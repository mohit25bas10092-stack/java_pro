import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Represents one immutable transaction record. */
public class Transaction {

    public enum Type { OPEN, DEPOSIT, WITHDRAW, TRANSFER_IN, TRANSFER_OUT }

    public static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final int id;
    private final String accountNumber;
    private final Type type;
    private final double amount;
    private final double balanceAfter;
    private final LocalDateTime timestamp;
    private final String note;

    public Transaction(int id, String accountNumber, Type type, double amount,
                       double balanceAfter, LocalDateTime timestamp, String note) {
        this.id = id;
        this.accountNumber = accountNumber;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
        this.timestamp = timestamp;
        this.note = note == null ? "" : note.replace("|", " ");
    }

    public int getId()                  { return id; }
    public String getAccountNumber()    { return accountNumber; }
    public Type getType()               { return type; }
    public double getAmount()           { return amount; }
    public double getBalanceAfter()     { return balanceAfter; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getNote()             { return note; }

    /** Format: id|accountNumber|type|amount|balanceAfter|timestamp|note */
    public String toFileLine() {
        return String.join("|",
                String.valueOf(id), accountNumber, type.name(),
                String.format(Locale.US, "%.2f", amount),
                String.format(Locale.US, "%.2f", balanceAfter),
                timestamp.format(FORMAT), note);
    }

    public static Transaction fromFileLine(String line) {
        String[] p = line.split("\\|", -1);
        if (p.length != 7) throw new IllegalArgumentException("Bad transaction record: " + line);
        return new Transaction(Integer.parseInt(p[0]), p[1], Type.valueOf(p[2]),
                Double.parseDouble(p[3]), Double.parseDouble(p[4]),
                LocalDateTime.parse(p[5], FORMAT), p[6]);
    }
}
