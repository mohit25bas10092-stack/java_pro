import java.util.List;

/** Builds a mini statement for an account and can save it to data/statement_<accountNumber>.txt. */
public class StatementGenerator {

    private StatementGenerator() { }

    public static String build(Account account, List<Transaction> history) {
        String line = "=".repeat(78);
        String thin = "-".repeat(78);
        StringBuilder sb = new StringBuilder();

        sb.append(line).append('\n');
        sb.append("                          MINI STATEMENT\n");
        sb.append(line).append('\n');
        sb.append(String.format("Account Number : %s%n", account.getAccountNumber()));
        sb.append(String.format("Account Holder : %s%n", account.getHolderName()));
        sb.append(String.format("Account Type   : %s%n", capitalise(account.getType().name())));
        sb.append(String.format("Current Balance: Rs.%.2f%n", account.getBalance()));
        sb.append(thin).append('\n');
        sb.append(String.format("%-4s %-19s %-13s %12s %12s  %s%n",
                "ID", "Date & Time", "Type", "Amount", "Balance", "Details"));
        sb.append(thin).append('\n');

        if (history.isEmpty()) {
            sb.append("No transactions found.\n");
        } else {
            for (Transaction t : history) {
                sb.append(String.format("%-4d %-19s %-13s %12.2f %12.2f  %s%n",
                        t.getId(), t.getTimestamp().format(Transaction.FORMAT),
                        t.getType().name(), t.getAmount(), t.getBalanceAfter(), t.getNote()));
            }
        }

        sb.append(thin).append('\n');
        if (account.isSavings()) {
            sb.append(String.format("Estimated interest @ %.0f%% p.a. : Rs.%.2f per year (about Rs.%.2f per month)%n",
                    InterestCalculator.ANNUAL_RATE * 100,
                    InterestCalculator.estimateAnnualInterest(account),
                    InterestCalculator.estimateMonthlyInterest(account)));
            sb.append("(Estimate only - no interest is credited to the balance.)\n");
        } else {
            sb.append("Current account - no interest applicable.\n");
        }
        sb.append(line).append('\n');
        return sb.toString();
    }

    /** Saves the statement to disk and returns the file path. */
    public static String save(Account account, List<Transaction> history) {
        return FileStorage.saveStatement(account.getAccountNumber(), build(account, history));
    }

    private static String capitalise(String s) {
        return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
    }
}
