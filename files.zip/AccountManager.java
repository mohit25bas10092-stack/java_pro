import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Handles opening, closing and looking up accounts. */
public class AccountManager {

    private static final int FIRST_NUMBER = 1001;
    private static final String PREFIX = "AC";

    private final List<Account> accounts;
    private int nextNumber;

    /**
     * @param loaded       accounts read from disk
     * @param transactions loaded transactions; used so numbers of closed accounts are never reused
     */
    public AccountManager(List<Account> loaded, List<Transaction> transactions) {
        this.accounts = new ArrayList<>(loaded);
        int highest = FIRST_NUMBER - 1;
        for (Account a : accounts) highest = Math.max(highest, numberOf(a.getAccountNumber()));
        for (Transaction t : transactions) highest = Math.max(highest, numberOf(t.getAccountNumber()));
        this.nextNumber = highest + 1;
    }

    private static int numberOf(String accountNumber) {
        try {
            return Integer.parseInt(accountNumber.substring(PREFIX.length()));
        } catch (RuntimeException e) {
            return 0;
        }
    }

    public Account openAccount(String holderName, Account.Type type, double initialDeposit) {
        if (holderName == null || holderName.trim().isEmpty())
            throw new IllegalArgumentException("Account holder name cannot be empty.");
        if (Double.isNaN(initialDeposit) || Double.isInfinite(initialDeposit) || initialDeposit < 0)
            throw new IllegalArgumentException("Initial deposit cannot be negative.");
        if (type == Account.Type.SAVINGS && initialDeposit < Account.SAVINGS_MIN_BALANCE)
            throw new IllegalArgumentException(String.format(
                    "Savings accounts need a minimum opening deposit of Rs.%.2f.", Account.SAVINGS_MIN_BALANCE));

        String number = PREFIX + nextNumber++;
        Account account = new Account(number, holderName.trim().replace("|", " "), type, initialDeposit);
        accounts.add(account);
        return account;
    }

    public Account findAccount(String accountNumber) {
        if (accountNumber == null) return null;
        for (Account a : accounts) {
            if (a.getAccountNumber().equalsIgnoreCase(accountNumber.trim())) return a;
        }
        return null;
    }

    public Account requireAccount(String accountNumber) {
        Account a = findAccount(accountNumber);
        if (a == null) throw new IllegalArgumentException("No account found with number " + accountNumber + ".");
        return a;
    }

    public List<Account> getAllAccounts() {
        return Collections.unmodifiableList(accounts);
    }

    public void closeAccount(String accountNumber) {
        Account a = requireAccount(accountNumber);
        if (a.getBalance() != 0)
            throw new IllegalStateException(String.format(
                    "Account %s still has a balance of Rs.%.2f. Withdraw or transfer it out before closing.",
                    a.getAccountNumber(), a.getBalance()));
        accounts.remove(a);
    }
}
