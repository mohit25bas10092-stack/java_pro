import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Deposit / withdraw / transfer logic. Every successful operation is logged as a Transaction. */
public class TransactionProcessor {

    private final AccountManager accountManager;
    private final List<Transaction> transactions;
    private int nextId;

    public TransactionProcessor(AccountManager accountManager, List<Transaction> loaded) {
        this.accountManager = accountManager;
        this.transactions = new ArrayList<>(loaded);
        int highest = 0;
        for (Transaction t : transactions) highest = Math.max(highest, t.getId());
        this.nextId = highest + 1;
    }

    public List<Transaction> getAllTransactions() {
        return Collections.unmodifiableList(transactions);
    }

    public List<Transaction> getTransactionsFor(String accountNumber) {
        List<Transaction> result = new ArrayList<>();
        for (Transaction t : transactions) {
            if (t.getAccountNumber().equalsIgnoreCase(accountNumber)) result.add(t);
        }
        return result;
    }

    /** Logs the opening deposit of a freshly created account. */
    public void recordOpening(Account account) {
        log(account, Transaction.Type.OPEN, account.getBalance(), "Account opened");
    }

    public Transaction deposit(String accountNumber, double amount) {
        validateAmount(amount);
        Account account = accountManager.requireAccount(accountNumber);
        account.deposit(amount);
        return log(account, Transaction.Type.DEPOSIT, amount, "Cash deposit");
    }

    public Transaction withdraw(String accountNumber, double amount) {
        validateAmount(amount);
        Account account = accountManager.requireAccount(accountNumber);
        checkWithdrawal(account, amount);
        account.withdraw(amount);
        return log(account, Transaction.Type.WITHDRAW, amount, "Cash withdrawal");
    }

    /** Moves money between two accounts; either both sides succeed or nothing changes. */
    public void transfer(String fromNumber, String toNumber, double amount) {
        validateAmount(amount);
        Account from = accountManager.requireAccount(fromNumber);
        Account to = accountManager.requireAccount(toNumber);
        if (from == to) throw new IllegalArgumentException("Cannot transfer to the same account.");
        checkWithdrawal(from, amount);

        from.withdraw(amount);
        to.deposit(amount);
        log(from, Transaction.Type.TRANSFER_OUT, amount, "Transfer to " + to.getAccountNumber());
        log(to, Transaction.Type.TRANSFER_IN, amount, "Transfer from " + from.getAccountNumber());
    }

    // ---- helpers ----

    private void validateAmount(double amount) {
        if (Double.isNaN(amount) || Double.isInfinite(amount) || amount <= 0)
            throw new IllegalArgumentException("Amount must be greater than zero.");
    }

    private void checkWithdrawal(Account account, double amount) {
        if (account.canWithdraw(amount)) return;
        if (account.getBalance() < amount)
            throw new IllegalStateException(String.format(
                    "Insufficient funds. Available balance: Rs.%.2f.", account.getBalance()));
        throw new IllegalStateException(String.format(
                "Denied: a savings account must keep a minimum balance of Rs.%.2f.",
                Account.SAVINGS_MIN_BALANCE));
    }

    private Transaction log(Account account, Transaction.Type type, double amount, String note) {
        Transaction t = new Transaction(nextId++, account.getAccountNumber(), type,
                Account.round2(amount), account.getBalance(), LocalDateTime.now(), note);
        transactions.add(t);
        return t;
    }
}
