import java.util.Locale;

/** Represents one bank account (savings or current). */
public class Account {

    public enum Type { SAVINGS, CURRENT }

    public static final double SAVINGS_MIN_BALANCE = 500.0;

    private final String accountNumber;
    private final String holderName;
    private final Type type;
    private double balance;

    public Account(String accountNumber, String holderName, Type type, double balance) {
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.type = type;
        this.balance = round2(balance);
    }

    public String getAccountNumber() { return accountNumber; }
    public String getHolderName()    { return holderName; }
    public Type getType()            { return type; }
    public double getBalance()       { return balance; }

    public boolean isSavings() { return type == Type.SAVINGS; }

    /**
     * A withdrawal is allowed if the balance never goes negative and, for savings
     * accounts, stays at or above the minimum balance. Withdrawing the entire
     * balance (down to exactly zero) is also allowed so that an account can be closed.
     */
    public boolean canWithdraw(double amount) {
        double remaining = round2(balance - amount);
        if (remaining < 0) return false;
        if (isSavings() && remaining != 0 && remaining < SAVINGS_MIN_BALANCE) return false;
        return true;
    }

    public void deposit(double amount) {
        balance = round2(balance + amount);
    }

    public void withdraw(double amount) {
        balance = round2(balance - amount);
    }

    /** Format: accountNumber|holderName|type|balance */
    public String toFileLine() {
        return String.join("|", accountNumber, holderName, type.name(),
                String.format(Locale.US, "%.2f", balance));
    }

    public static Account fromFileLine(String line) {
        String[] p = line.split("\\|", -1);
        if (p.length != 4) throw new IllegalArgumentException("Bad account record: " + line);
        return new Account(p[0], p[1], Type.valueOf(p[2]), Double.parseDouble(p[3]));
    }

    public static double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
