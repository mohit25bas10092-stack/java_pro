import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** CLI menu and program entry point. */
public class Main {

    private static final Scanner in = new Scanner(System.in);

    private static AccountManager accountManager;
    private static TransactionProcessor processor;

    public static void main(String[] args) {
        List<Account> accounts = FileStorage.loadAccounts();
        List<Transaction> transactions = FileStorage.loadTransactions();
        accountManager = new AccountManager(accounts, transactions);
        processor = new TransactionProcessor(accountManager, transactions);

        System.out.println("=== Bank Account Manager ===");
        System.out.printf("Loaded %d account(s) and %d transaction(s).%n",
                accounts.size(), transactions.size());

        try {
            boolean running = true;
            while (running) {
                printMenu();
                String choice = prompt("> ");
                System.out.println();
                try {
                    switch (choice) {
                        case "1": openAccount();   break;
                        case "2": viewAccounts();  break;
                        case "3": deposit();       break;
                        case "4": withdraw();      break;
                        case "5": transfer();      break;
                        case "6": miniStatement(); break;
                        case "7": closeAccount();  break;
                        case "0": running = false; break;
                        default:  System.out.println("Invalid choice. Please enter a number from the menu.");
                    }
                } catch (IllegalArgumentException | IllegalStateException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        } catch (NoSuchElementException e) {
            System.out.println("\nInput ended - saving and exiting.");
        }

        save();
        System.out.println("Goodbye!");
    }

    // ---- menu actions ----

    private static void printMenu() {
        System.out.println();
        System.out.println("What do you want to do?");
        System.out.println("1. Open a new account");
        System.out.println("2. View all accounts");
        System.out.println("3. Deposit money");
        System.out.println("4. Withdraw money");
        System.out.println("5. Transfer money");
        System.out.println("6. View mini statement");
        System.out.println("7. Close an account");
        System.out.println("0. Save and exit");
    }

    private static void openAccount() {
        String name = prompt("Account holder name: ");
        String typeText = prompt("Account type (savings/current): ").toLowerCase();
        Account.Type type;
        if (typeText.equals("savings") || typeText.equals("s")) type = Account.Type.SAVINGS;
        else if (typeText.equals("current") || typeText.equals("c")) type = Account.Type.CURRENT;
        else throw new IllegalArgumentException("Account type must be 'savings' or 'current'.");

        double deposit = readAmount("Initial deposit (Rs.): ");
        Account account = accountManager.openAccount(name, type, deposit);
        processor.recordOpening(account);
        System.out.printf("Account opened! Number: %s | Holder: %s | Type: %s | Balance: Rs.%.2f%n",
                account.getAccountNumber(), account.getHolderName(),
                account.getType().name().toLowerCase(), account.getBalance());
    }

    private static void viewAccounts() {
        List<Account> accounts = accountManager.getAllAccounts();
        if (accounts.isEmpty()) {
            System.out.println("No accounts yet. Choose 1 to open one.");
            return;
        }
        System.out.printf("%-9s %-24s %-9s %14s%n", "Account", "Holder", "Type", "Balance (Rs.)");
        System.out.println("-".repeat(59));
        for (Account a : accounts) {
            System.out.printf("%-9s %-24s %-9s %14.2f%n", a.getAccountNumber(),
                    truncate(a.getHolderName(), 24), a.getType().name().toLowerCase(), a.getBalance());
        }
    }

    private static void deposit() {
        String number = prompt("Account number: ");
        double amount = readAmount("Amount to deposit (Rs.): ");
        Transaction t = processor.deposit(number, amount);
        System.out.printf("Deposited Rs.%.2f. New balance: Rs.%.2f%n", t.getAmount(), t.getBalanceAfter());
    }

    private static void withdraw() {
        String number = prompt("Account number: ");
        double amount = readAmount("Amount to withdraw (Rs.): ");
        Transaction t = processor.withdraw(number, amount);
        System.out.printf("Withdrew Rs.%.2f. New balance: Rs.%.2f%n", t.getAmount(), t.getBalanceAfter());
    }

    private static void transfer() {
        String from = prompt("From account number: ");
        String to = prompt("To account number: ");
        double amount = readAmount("Amount to transfer (Rs.): ");
        processor.transfer(from, to, amount);
        System.out.printf("Transferred Rs.%.2f from %s to %s.%n", amount,
                from.trim().toUpperCase(), to.trim().toUpperCase());
        System.out.printf("New balances -> %s: Rs.%.2f | %s: Rs.%.2f%n",
                from.trim().toUpperCase(), accountManager.requireAccount(from).getBalance(),
                to.trim().toUpperCase(), accountManager.requireAccount(to).getBalance());
    }

    private static void miniStatement() {
        Account account = accountManager.requireAccount(prompt("Account number: "));
        List<Transaction> history = processor.getTransactionsFor(account.getAccountNumber());
        System.out.println(StatementGenerator.build(account, history));
        String path = StatementGenerator.save(account, history);
        System.out.println("Statement saved to " + path);
    }

    private static void closeAccount() {
        String number = prompt("Account number to close: ");
        accountManager.closeAccount(number);
        System.out.println("Account " + number.trim().toUpperCase() + " has been closed.");
    }

    // ---- helpers ----

    private static void save() {
        try {
            FileStorage.saveAccounts(accountManager.getAllAccounts());
            FileStorage.saveTransactions(processor.getAllTransactions());
            System.out.println("All data saved to the data/ folder.");
        } catch (IOException e) {
            System.out.println("Error: could not save data - " + e.getMessage());
        }
    }

    private static String prompt(String text) {
        System.out.print(text);
        return in.nextLine().trim();
    }

    private static double readAmount(String text) {
        String raw = prompt(text);
        try {
            return Double.parseDouble(raw);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("'" + raw + "' is not a valid amount.");
        }
    }

    private static String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
