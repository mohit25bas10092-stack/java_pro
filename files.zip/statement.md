# Problem Statement

## Title
Bank Account Manager – a command-line banking simulator in Java

## Background
Small organisations, student projects and training environments often track account balances in manual ledgers, spreadsheets or scattered notes. This makes it easy to lose track of balances, apply rules inconsistently (for example, minimum balances), and impossible to audit what actually happened to an account.

## Problem
There is no simple, offline, self-contained tool that lets a user manage several bank accounts, enforce basic banking rules automatically, and keep a reliable record of every transaction.

## Objectives
1. Let a user open savings and current accounts with an initial deposit.
2. Support deposits, withdrawals and account-to-account transfers.
3. Enforce banking rules automatically:
   - Savings accounts need a minimum opening deposit of Rs.500 and must maintain a balance of at least Rs.500.
   - Current accounts have no minimum balance.
   - An account can be closed only when its balance is zero.
4. Record every operation as a transaction and produce a mini statement for any account.
5. Estimate annual interest (4% p.a.) for savings accounts without altering the balance.
6. Persist all data in plain text files so nothing is lost between runs.

## Scope

**In scope**
- Command-line interface, single user, offline use
- Savings and current accounts
- Deposit, withdraw, transfer, statement, close
- Text-file persistence (`data/accounts.txt`, `data/transactions.txt`)
- Estimated (not credited) interest for savings accounts

**Out of scope**
- Authentication, PINs or multi-user access
- Graphical or web interface
- Real payment gateways or networked banking
- Credit of interest to the balance, loans, cards or multi-currency support

## Target Users
Students, instructors and hobbyists who want a small, readable example of a banking system, or a lightweight offline tool to practise account-management logic.

## Functional Requirements
| # | Requirement |
|---|-------------|
| F1 | Open an account (savings/current) with auto-generated numbers starting at AC1001 |
| F2 | List all accounts with holder, type and balance |
| F3 | Deposit any positive amount into an existing account |
| F4 | Withdraw money, rejecting overdrafts and savings minimum-balance violations |
| F5 | Transfer money between two different accounts atomically |
| F6 | Show and save a mini statement with full transaction history |
| F7 | Show estimated annual interest on savings statements |
| F8 | Close an account only when its balance is zero |
| F9 | Save all data on exit and reload it on the next run |

## Non-Functional Requirements
- **Simplicity:** core Java only, no external libraries or database.
- **Reliability:** invalid input (bad amounts, unknown accounts) shows a clear message and never crashes the program or changes balances.
- **Auditability:** every successful balance change has a matching transaction record.
- **Portability:** runs on any system with JDK 17 or newer.

## Design Approach
The program is split into small classes, each with one job: `Main` (menu), `Account` and `Transaction` (data), `AccountManager` (open/close/find), `TransactionProcessor` (deposit/withdraw/transfer), `InterestCalculator`, `StatementGenerator`, and `FileStorage` (text-file persistence).

## Expected Outcome
A working command-line application that lets a user run a small bank end to end – open accounts, move money, review statements and close accounts – with the rules above enforced and all data preserved between sessions.
